package shul;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PrintAddressLabels {
private ArrayList<AddressLabel> labels;



public void printMemberAddressLabels(Connection connection) throws SQLException
{
	
	String sqlSelect = "select m.MembershipID, p.title, p.FName, Midinit, p.LName, "
			+ "a.street, a.AptNum, a.City,a.AddrState,a.Zip from Person p "
			+ "join Membership m on p.MembershipID = m.MembershipID join [Address] a "
			+ "on m.membershipaddress = a.addressid order by MembershipID, p.gender desc";
	
	PreparedStatement statement = connection.prepareStatement(sqlSelect);
	   //execute the statement    	   
	ResultSet rs = statement.executeQuery();
	
	//if the set is not null
	/*if(rs.first()){

		rs.beforeFirst();
	
		while(rs.next()){
		AddressLabel addLabel = new AddressLabel();
				
				
		labels.add(addLabel);
		}
		}
*/	
}
}