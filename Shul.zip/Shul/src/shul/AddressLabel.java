package shul;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddressLabel {
	private String formattedName;
	private String formattedAddress;
	
	private static Integer AddressLabelID;
	
	
	public AddressLabel(Person a, Person b){
		StringBuilder info = new StringBuilder();
		
		info.append(a.getTitle());		
		info.append(" ");		
		info.append(a.getFirstName());
		info.append(" ");
		if(!(a.getMidInitial() == null)){
			info.append(a.getMidInitial());
			info.append(" ");
		}
		info.append("and");
		info.append(b.getTitle());
		info.append(" ");
		info.append(b.getFirstName());
		info.append(" ");
		if(!(b.getMidInitial() == null)){
			info.append(b.getMidInitial());
			info.append(" ");
		}
		info.append(b.getLastName());
		
		this.formattedName = info.toString();
		
		Membership aMembership = a.getMembershipByID(a.getMembershipID());
		
	}
	
	public AddressLabel(Person a){

	}
	public AddressLabel fillAddressLabel(Membership aMembership, Connection connection) throws SQLException{
		
	
	}
	
	

}
