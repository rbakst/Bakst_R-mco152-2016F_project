package shul;

public enum MembershipType 
{	
	FULL,
	FRIEND, 
	ASSOCIATE

}
