package shul;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect 
{
	Connection con = DriverManager.getConnection(host, username, password);
}
